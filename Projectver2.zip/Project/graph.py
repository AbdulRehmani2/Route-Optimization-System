import json
import networkx as nx
import matplotlib.pyplot as plt

class Node:
    
    def __init__(self, value, latitude, longitude):
        self.value = value
        self.neighbors = []
        self.latitude = latitude
        self.longitude = longitude
        self.status = "unvisited"
        
    def hasNeighbor(self):
        return self.neighbors == []
    
    def getNeighbor(self):
        return self.neighbors

    def addNeighbor(self, vertex):
        self.neighbor.append(vertex)        
        
class Graph:
    def __init__(self):
        self.vertices = []
        
    def addVertex(self, vertex):
        self.vertices.append(vertex)
        
    def addEdge(self, u, v):
        u.neighbors.append(v)
        v.neighbors.append(u)
        
    def printVertices(self):
        for i in self.vertices:
            print(i.value, i.latitude, i.longitude)
            for j in i.neighbors:
                print(j.value)
            
def createMap(graph, data):
    list = []
    for i in data:
        district = Node(i, data[i]["coordinates"]["latitude"], data[i]["coordinates"]["longitude"])
        graph.addVertex(district)
        list.append(district.value)
    for i in graph.vertices:
        for j in data[i.value]["adjacent_districts"]:
            index = list.index(j)
            graph.addEdge(i, graph.vertices[index])
    return graph

# file = open("./data.txt", "r")
# data = json.load(file)
        
# for i in data:
#     print(i["coordinates"]["latitude"])
    
# myGraph = Graph()
# myGraph = createMap(myGraph, data)
# myGraph.visualizeGraph()
# myGraph.printVertices()
# visualizeGraph(myGraph)
# node1 = Node(1)
# node2 = Node(2)
# node3 = Node(3)
# node4 = Node(4)
# node5 = Node(5)

# myGraph.addVertex(node1)
# myGraph.addVertex(node2)
# myGraph.addVertex(node3)
# myGraph.addVertex(node4)
# myGraph.addVertex(node5)

# myGraph.addEdge(node1, node2)
# myGraph.addEdge(node2, node3)
# myGraph.addEdge(node3, node4)
# myGraph.addEdge(node4, node5)
# myGraph.addEdge(node5, node1)
